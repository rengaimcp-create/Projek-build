# EMENG×KAKORO PROXXY

Native Android project using Kotlin, Jetpack Compose, Material 3, package `com.emeng.proxxy`, minimum Android 8.0/API 26, Gradle Kotlin DSL.

## Implemented in this project
- Dashboard and separate AIM, VISUAL, EXTRA, INFO DEVICE, OVERLAY API, FLOATING MENU, PRESET MANAGER, TRAINING ARENA, APP SETTINGS sections.
- Crosshair Studio with live preview and shape (plus/dot/circle), color, size and opacity controls.
- System crosshair overlay through Android `WindowManager.TYPE_APPLICATION_OVERLAY`, with explicit permission flow and stop control.
- Local preset save/apply/delete.
- Local tap-target practice with hit/miss counts and accuracy.
- Device information and local settings reset.

## Important limitations
This is a standalone utility. It does not inject code into Free Fire, alter its internal aiming system, read game memory or screen, reveal hidden enemy positions, or bypass anti-cheat. Crosshair overlay is visual-only. AIM values/presets are stored locally and are not automatically applied to Free Fire.

## Build
Open the folder in Android Studio with JDK 17, sync Gradle, then use **Build > Build APK(s)**. The project does not include a Gradle wrapper binary. No build or device test has been run in this environment; verify the build and overlay behavior on your device.
