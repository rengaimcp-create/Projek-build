package com.emeng.proxxy.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color as C
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CrosshairOverlayService : Service() {
    private var wm: WindowManager? = null
    private var overlay: CrosshairView? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (overlay == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            overlay = CrosshairView(this)
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            try { wm?.addView(overlay,lp) } catch (_: Exception) { stopSelf() }
        } else overlay?.invalidate()
        return START_NOT_STICKY
    }
    override fun onDestroy() { try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}; overlay=null; wm=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
private class CrosshairView(context: Context): View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap=Paint.Cap.ROUND }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p=context.getSharedPreferences("emeng_settings",Context.MODE_PRIVATE)
        val size=p.getFloat("size",28f)*resources.displayMetrics.density; val alpha=(p.getFloat("opacity",.9f)*255).toInt().coerceIn(0,255)
        val color=when(p.getString("color","CYAN")){"RED"->C.rgb(255,53,79);"GREEN"->C.rgb(77,255,145);"WHITE"->C.WHITE;else->C.rgb(66,232,224)}
        paint.color=(color and 0x00ffffff) or (alpha shl 24); paint.strokeWidth=(size/12f).coerceIn(1.5f*resources.displayMetrics.density,5f*resources.displayMetrics.density)
        val x=width/2f; val y=height/2f; val r=size/2f; val shape=p.getString("shape","PLUS")
        when(shape){
            "DOT"->{paint.style=Paint.Style.FILL;canvas.drawCircle(x,y,paint.strokeWidth*1.3f,paint)}
            "CIRCLE"->{paint.style=Paint.Style.STROKE;canvas.drawCircle(x,y,r,paint);canvas.drawLine(x-r-paint.strokeWidth,y,x-r/2,y,paint);canvas.drawLine(x+r/2,y,x+r+paint.strokeWidth,y,paint);canvas.drawLine(x,y-r-paint.strokeWidth,x,y-r/2,paint);canvas.drawLine(x,y+r/2,x,y+r+paint.strokeWidth,paint)}
            else->{paint.style=Paint.Style.STROKE;canvas.drawLine(x-r,y,x-r/3,y,paint);canvas.drawLine(x+r/3,y,x+r,y,paint);canvas.drawLine(x,y-r,x,y-r/3,paint);canvas.drawLine(x,y+r/3,x,y+r,paint);paint.style=Paint.Style.FILL;canvas.drawCircle(x,y,paint.strokeWidth*.7f,paint)}
        }
    }
}
